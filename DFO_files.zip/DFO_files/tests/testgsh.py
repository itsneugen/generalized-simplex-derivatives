import numpy as np
import sympy as sp
import argparse
from gsg import gsg_from_func, gsg_from_values, gsg_error_bound, estimate_lipschitz_gradient_from_symbolic
import ast
import sys

def parse_matrix(string, n, label="S"):
    try:
        rows = string.strip().split(";")
        mat = np.array([list(map(float, row.strip().split())) for row in rows]).T
        if mat.shape[0] != n:
            raise ValueError(f"{label} must have {n} rows (got {mat.shape[0]})")
        return mat
    except Exception as e:
        print(f"Error parsing {label} matrix: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Test Generalized Simplex Gradient (GSG).", formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--x0", nargs="+", type=float, help="Base point x0 (space-separated values)")
    parser.add_argument("--function", type=str, help="Function as string (e.g., 'x0**2 + 3*x1**2')")
    parser.add_argument("--h", type=float, help="Step size (e.g., 0.01)")
    parser.add_argument("--S", type=str, help="Direction matrix S as string (e.g., '0.01 0; 0 0.01')")
    parser.add_argument("--values", type=str, help="Comma-separated function values for manual mode")
    parser.add_argument("--manual", action="store_true", help="Use function-value-only mode")
    parser.add_argument("--interactive", action="store_true", help="Run in interactive mode")

    args = parser.parse_args()

    if args.interactive:
        # Ask all inputs interactively
        n = int(input("Enter number of variables (n): "))
        x0 = np.array(list(map(float, input(f"Enter x0 ({n} values): ").split())))
        fun_str = input("Enter function (e.g., 'x0**2 + 3*x1**2'): ")
        h = float(input("Enter step size h (e.g., 0.01): "))
        S = h * np.eye(n)
        fun_expr = sp.sympify(fun_str)
        x_syms = sp.symbols(f"x0:{n}")
        f = sp.lambdify(x_syms, fun_expr, "numpy")

        print("\nUsing symbolic function and standard basis:")
        print("S matrix:\n", S)
        gsg = gsg_from_func(f, x0, S)
        print("Approximate gradient (GSG):", gsg)

        # True gradient
        grad = np.array([sp.diff(fun_expr, sym) for sym in x_syms])
        grad_func = sp.lambdify(x_syms, grad, "numpy")
        true_grad = np.array(grad_func(*x0), dtype=float)
        print("True gradient:", true_grad)
        print("Error:", np.abs(true_grad - gsg))

        # Lipschitz-based bound
        L = estimate_lipschitz_gradient_from_symbolic(x_syms, fun_expr)(*x0)
        print("Estimated Lipschitz constant L:", L)
        bound = gsg_error_bound(S, L)
        print("Lipschitz-based error bound:", bound)

    elif args.manual:
        # Manual function-value-only mode
        if args.x0 is None or args.S is None or args.values is None:
            print("In manual mode, provide --x0, --S, and --values.")
            return
        x0 = np.array(args.x0, dtype=float)
        n = len(x0)
        S = parse_matrix(args.S, n)
        v = np.array(list(map(float, args.values.strip().split(","))))
        print("\nUsing function values only:")
        print("S matrix:\n", S)
        print("v values:", v)
        gsg = gsg_from_values(v, S)
        print("Approximate gradient (GSG):", gsg)

    else:
        # Standard symbolic mode with CLI args
        if args.x0 is None or args.function is None or args.h is None:
            print("Please provide --x0, --function, and --h.")
            return
        x0 = np.array(args.x0, dtype=float)
        n = len(x0)
        h = args.h
        S = h * np.eye(n)
        fun_expr = sp.sympify(args.function)
        x_syms = sp.symbols(f"x0:{n}")
        f = sp.lambdify(x_syms, fun_expr, "numpy")

        print("\nUsing symbolic function and standard basis:")
        print("S matrix:\n", S)
        gsg = gsg_from_func(f, x0, S)
        print("Approximate gradient (GSG):", gsg)

        # True gradient
        grad = np.array([sp.diff(fun_expr, sym) for sym in x_syms])
        grad_func = sp.lambdify(x_syms, grad, "numpy")
        true_grad = np.array(grad_func(*x0), dtype=float)
        print("True gradient:", true_grad)
        print("Error:", np.abs(true_grad - gsg))

        # Lipschitz-based bound
        L = estimate_lipschitz_gradient_from_symbolic(x_syms, fun_expr)(*x0)
        print("Estimated Lipschitz constant L:", L)
        bound = gsg_error_bound(S, L)
        print("Lipschitz-based error bound:", bound)

if __name__ == "__main__":
    main()
