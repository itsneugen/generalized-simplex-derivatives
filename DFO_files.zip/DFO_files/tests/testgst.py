import numpy as np
import sympy as sp
from tres import gst_from_func, gst_error_bound, estimate_lipschitz_tressian_from_symbolic
import argparse

def main():
    parser = argparse.ArgumentParser(description="Test the Generalized Simplex Tressian (Third Derivative Tensor)")
    parser.add_argument('--x0', nargs='+', type=float, help='Base point x0 (space-separated list)', required=True)
    parser.add_argument('--function', type=str, help='Function in terms of x0, x1, ..., e.g. "x0**2*x1 + 3*x1**2"', required=True)
    parser.add_argument('--h', type=float, default=0.01, help='Step size (default: 0.01)')
    args = parser.parse_args()

    x0 = np.array(args.x0)
    n = len(x0)
    h = args.h

    # Standard basis
    S = h * np.eye(n)
    T = h * np.eye(n)
    U = h * np.eye(n)

    # Normalize direction matrices
    delta_S = max(np.linalg.norm(S[:, i]) for i in range(n))
    delta_T = max(np.linalg.norm(T[:, j]) for j in range(n))
    delta_U = max(np.linalg.norm(U[:, k]) for k in range(n))

    S = S / delta_S
    T = T / delta_T
    U = U / delta_U

    # Symbolic setup
    x_syms = sp.symbols(f'x0:{n}')
    f_expr = sp.sympify(args.function)
    f_func = sp.lambdify(x_syms, f_expr, 'numpy')

    # GST Approximation
    T_approx = gst_from_func(f_func, x0, S, T, U)
    print("\nApproximate Tressian (3rd-order tensor) at x0:")
    for i in range(n):
        print(f"T[{i}, :, :]:\n{T_approx[i]}")

    # Symbolic Tressian
    T_sym = [[[sp.diff(f_expr, x_syms[i], x_syms[j], x_syms[k]) for k in range(n)] for j in range(n)] for i in range(n)]
    T_true = np.zeros((n, n, n))
    for i in range(n):
        for j in range(n):
            for k in range(n):
                T_true[i, j, k] = T_sym[i][j][k].evalf(subs={x_syms[t]: x0[t] for t in range(n)})

    print("\nTrue Tressian at x0:")
    for i in range(n):
        print(f"T[{i}, :, :]:\n{T_true[i]}")

    # Error
    print("\nAbsolute Error Tensor:")
    for i in range(n):
        print(f"|T_approx - T_true|[{i}]:\n{np.abs(T_approx[i] - T_true[i])}")

    # Lipschitz constant and error bound
    lipschitz_func = estimate_lipschitz_tressian_from_symbolic(x_syms, f_expr)
    L = lipschitz_func(*x0)
    bound = gst_error_bound(S, T, U, L)
    print("\nEstimated Lipschitz constant of Tressian:", L)
    print("Lipschitz-based error bound:", bound)

if __name__ == '__main__':
    main()
