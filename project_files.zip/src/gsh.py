import numpy as np

def gsh_from_func(fun, x0, S, T):
    """
    Compute the Generalized Simplex Hessian (GSH) using function evaluations.

    Parameters:
        fun : callable
            A Python function that takes n inputs and returns a scalar (R^n -> R).
        x0 : ndarray of shape (n,)
            Base point at which to estimate the Hessian.
        S : ndarray of shape (n, m)
            Direction matrix for S directions.
        T : ndarray of shape (n, k)
            Direction matrix for T directions.

    Returns:
        H_approx : ndarray of shape (n, n)
            Approximate Hessian matrix at x0.
    """
    x0 = np.asarray(x0, dtype=float)
    S = np.asarray(S, dtype=float)
    T = np.asarray(T, dtype=float)
    n, m = S.shape
    _, k = T.shape

    delta = np.zeros((m, k))
    for i in range(m):
        for j in range(k):
            f1 = fun(*(x0 + S[:, i] + T[:, j]))
            f2 = fun(*(x0 + S[:, i]))
            f3 = fun(*(x0 + T[:, j]))
            f4 = fun(*x0)
            delta[i, j] = f1 - f2 - f3 + f4

    S_pinv = np.linalg.pinv(S.T)
    T_pinv = np.linalg.pinv(T.T)
    H_approx = S_pinv @ delta @ T_pinv.T
    return H_approx

def gsh_from_values(v, S, T):
    """
    Compute the GSH using pre-evaluated function values.

    Parameters:
        v : ndarray of shape (m+1, k+1)
            Grid of function values:
                v[0,0] = f(x0),
                v[i,0] = f(x0 + s_i),
                v[0,j] = f(x0 + t_j),
                v[i,j] = f(x0 + s_i + t_j)
        S : ndarray of shape (n, m)
            S direction matrix.
        T : ndarray of shape (n, k)
            T direction matrix.

    Returns:
        H_approx : ndarray of shape (n, n)
            Approximate Hessian.
    """
    v = np.asarray(v, dtype=float)
    m = S.shape[1]
    k = T.shape[1]

    delta = v[1:,1:] - v[1:,0:1] - v[0:1,1:] + v[0,0]
    S_pinv = np.linalg.pinv(S.T)
    T_pinv = np.linalg.pinv(T.T)
    H_approx = S_pinv @ delta @ T_pinv.T
    return H_approx

def gsh_error_bound(S, T, L_hess):
    """
    Estimate the error bound of the GSH approximation.

    This uses the special case where all Ti are equal (T1 = T2 = ... = T).

    Parameters:
        S : ndarray of shape (n, m)
        T : ndarray of shape (n, k)
        L_hess : float
            Lipschitz constant of the Hessian.

    Returns:
        bound : float
            Upper bound on the error of the GSH approximation.
    """
    m = S.shape[1]
    k = T.shape[1]
    delta_S = max(np.linalg.norm(S[:, i]) for i in range(m))
    delta_T = max(np.linalg.norm(T[:, j]) for j in range(k))
    delta_u = max(delta_S, delta_T)
    delta_l = min(delta_S, delta_T)
    S_pinv_norm = np.linalg.norm(np.linalg.pinv(S.T), 2)
    T_pinv_norm = np.linalg.norm(np.linalg.pinv(T.T), 2)

    bound = 4 * np.sqrt(m * k) * L_hess * (delta_u / delta_l) * S_pinv_norm * T_pinv_norm * delta_u
    return bound

def estimate_lipschitz_hessian_from_symbolic(x_syms, f_expr):
    """
    Estimate the Lipschitz constant of the Hessian using third derivatives.

    Parameters:
        x_syms : list of sympy symbols
            Variables used in the symbolic expression.
        f_expr : sympy expression
            Function expression (e.g., x0**2 + x0*x1 + ...)

    Returns:
        lipschitz_func : callable
            A function that returns Lipschitz estimate for the Hessian at any point.
    """
    import sympy as sp
    n = len(x_syms)
    third_derivs = [
        sp.diff(f_expr, x_syms[i], x_syms[j], x_syms[k])
        for i in range(n) for j in range(n) for k in range(n)
    ]

    def lipschitz_func(*x0):
        vals = [abs(d3.evalf(subs=dict(zip(x_syms, x0)))) for d3 in third_derivs]
        return max(vals)

    return lipschitz_func
