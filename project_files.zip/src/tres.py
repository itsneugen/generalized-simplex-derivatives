import numpy as np

def gst_from_func(fun, x0, S, T, U):
    """
    Compute the Generalized Simplex Tressian (GST) from a function.

    Parameters:
        fun : callable
            Scalar function f: R^n -> R
        x0 : ndarray (n,)
            Base point
        S, T, U : ndarray (n, m), (n, k), (n, l)
            Direction matrices for 3rd-order approximation

    Returns:
        Tressian approximation: ndarray (n, n, n)
    """
    x0 = np.asarray(x0, dtype=float)
    S = np.asarray(S, dtype=float)
    T = np.asarray(T, dtype=float)
    U = np.asarray(U, dtype=float)
    
    m, k, l = S.shape[1], T.shape[1], U.shape[1]
    
    # Build delta tensor
    delta = np.zeros((m, k, l))
    for i in range(m):
        for j in range(k):
            for r in range(l):
                f111 = fun(*(x0 + S[:, i] + T[:, j] + U[:, r]))
                f100 = fun(*(x0 + S[:, i]))
                f010 = fun(*(x0 + T[:, j]))
                f001 = fun(*(x0 + U[:, r]))
                f110 = fun(*(x0 + S[:, i] + T[:, j]))
                f101 = fun(*(x0 + S[:, i] + U[:, r]))
                f011 = fun(*(x0 + T[:, j] + U[:, r]))
                f000 = fun(*x0)
                
                delta[i, j, r] = (
                    f111 - f110 - f101 - f011 + f100 + f010 + f001 - f000
                )

    S_pinv = np.linalg.pinv(S.T)
    T_pinv = np.linalg.pinv(T.T)
    U_pinv = np.linalg.pinv(U.T)

    # Tensor product with 3 pseudoinverses
    Tressian = np.einsum('ia,jb,kc,ijk->abc', S_pinv, T_pinv, U_pinv, delta)
    return Tressian

def gst_from_values(v, S, T, U):
    """
    Compute the GST using pre-evaluated function values.

    Parameters:
        v : ndarray of shape (m+1, k+1, l+1)
            v[i,j,r] = f(x0 + s_i + t_j + u_r), with appropriate special cases
        S, T, U : ndarray (n, m), (n, k), (n, l)
            Direction matrices

    Returns:
        Tressian estimate: ndarray (n, n, n)
    """
    v = np.asarray(v, dtype=float)
    m, k, l = S.shape[1], T.shape[1], U.shape[1]

    delta = (
        v[1:,1:,1:] - v[1:,1:,0:1] - v[1:,0:1,1:] - v[0:1,1:,1:]
        + v[1:,0:1,0:1] + v[0:1,1:,0:1] + v[0:1,0:1,1:] - v[0,0,0]
    )

    S_pinv = np.linalg.pinv(S.T)
    T_pinv = np.linalg.pinv(T.T)
    U_pinv = np.linalg.pinv(U.T)

    Tressian = np.einsum('ia,jb,kc,ijk->abc', S_pinv, T_pinv, U_pinv, delta)
    return Tressian

def gst_error_bound(S, T, U, L_tress):
    """
    Error bound for Generalized Simplex Tressian (GST), assuming Ti = T, Uj = U.
    """
    m = S.shape[1]
    k = T.shape[1]
    l = U.shape[1]
    delta_S = max(np.linalg.norm(S[:, i]) for i in range(m))
    delta_T = max(np.linalg.norm(T[:, j]) for j in range(k))
    delta_U = max(np.linalg.norm(U[:, p]) for p in range(l))
    
    delta_u = max(delta_S, delta_T, delta_U)
    delta_l = min(delta_S, delta_T, delta_U)
    
    S_pinv = np.linalg.pinv(S.T)
    T_pinv = np.linalg.pinv(T.T)
    U_pinv = np.linalg.pinv(U.T)
    
    bound = 8 * np.sqrt(m * k * l) * L_tress * (delta_u / delta_l) * \
            np.linalg.norm(S_pinv) * np.linalg.norm(T_pinv) * np.linalg.norm(U_pinv) * delta_u

    return bound

def estimate_lipschitz_tressian_from_symbolic(x_syms, f_expr):
    """
    Estimate the Lipschitz constant of the third derivative (Tressian) using max of 4th-order derivatives.
    """
    import sympy as sp
    n = len(x_syms)
    fourth_derivs = []
    for i in range(n):
        for j in range(n):
            for k in range(n):
                for l in range(n):
                    d4 = sp.diff(f_expr, x_syms[i], x_syms[j], x_syms[k], x_syms[l])
                    fourth_derivs.append(d4)

    def lipschitz_func(*x0):
        vals = [abs(d4.evalf(subs=dict(zip(x_syms, x0)))) for d4 in fourth_derivs]
        return max(vals)
    
    return lipschitz_func
